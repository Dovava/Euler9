﻿using System;

namespace Euler9
{
    class Program
    {
        public static int num1 =0;
        public static int num2 = 0;
        public static int num3 = 0;
        public static int ONE = 0;
        public static int TWO = 0;
        public static int THREE = 0;
        static void Main(string[] args)
        {
            for (int one = 0; one < 501; one++) {
                for (int two = 0; two < 501; two++) {
                    for (int three = 0; three < 501; three++) {
                        num1 = one;
                        num2 = two;
                        num3 = three;
                        if (check(num1, num2, num3) && (num1 * num1) + (num2 * num2) == (num3 * num3) && num1 + num2 + num3 == 1000)
                        {
                            ONE = num1;
                            TWO = num2;
                            THREE = num3;
                        }
                    }
                }
            }
            Console.WriteLine(ONE * TWO * THREE);
        }
        static bool check(int one, int two, int three) {
            bool c1 = one < two;
            bool c2 = one < three;
            bool c3 = two > one;
            bool c4 = two < three;
            bool c5 = three > one;
            bool c6 = three > two;
            return c1 && c2 && c3 && c4 && c5 && c6;
        }
    }
}
